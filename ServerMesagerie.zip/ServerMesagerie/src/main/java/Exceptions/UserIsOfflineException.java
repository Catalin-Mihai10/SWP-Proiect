package Exceptions;

public class UserIsOfflineException extends Exception {
    public UserIsOfflineException() { super("User is offline");}

}
